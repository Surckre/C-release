#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>

int main() {
	char name[10];
	printf("Whats Your Name: ");
	scanf("%s", name);
	printf("\nHello %s!", name);
	getchar();
	getchar();
	return 0;
}